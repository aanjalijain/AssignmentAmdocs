package com.uxpsystems.assignment.test.config;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "com.uxpsystems.assignment")
public class TestBeanConfig {

}